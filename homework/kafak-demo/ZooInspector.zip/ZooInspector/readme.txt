进入 build 目录后执行： java -jar zookeeper-dev-ZooInspector.jar

点击左上角的连接按钮，输入 ZK服务地址 ip:2181 点击OK 即可查看ZK节点信息